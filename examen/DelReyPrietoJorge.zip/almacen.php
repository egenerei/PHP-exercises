<?php
$juegos5=array("Everdell" => 65.00,"Catan Plus" => 58.50,"Carcassonne" => 27.00,"Takenoko"=>50.50,"Aventureros en el tren" => 47.90);
$comics5=array("Blacksad 7: Todo cae (2ª Parte)" => 15.00,"La ciudad de los prodigios" => 23.75,"Arrugas" => 14.25,"Maus" => 22.70,"El cielo en la cabeza" => 26.60);
$novelas5=array("Harry Potter 3: EL prisionero de Azkabán" => 18.00,"Los pilares de la Tierra" => 14.70,"El clan del oso cavernario" => 12.80,"La armadura de la luz" => 24.90,"La sombra del viento" => 22.00);