<?php
#Examen Jorge Del Rey Prieto
const nombre_res5="JUEGATLEO"; #constante
$direccion5 ="Calle Primavera, 24";
$email5 ="contacto@juegatleo.es" ;
$promocion5 = "BLACK FRIDAY" ;
$descuento5 = 15;
$diasEntrega5 = 4; 